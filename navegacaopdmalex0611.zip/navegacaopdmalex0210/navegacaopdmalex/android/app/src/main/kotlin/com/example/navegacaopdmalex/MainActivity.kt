package com.example.navegacaopdmalex

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
